/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Hashtable;

/**
 *
 * @author Leyla
 */
public class GeoCrowd {
public static double minLatitude=Double.MAX_VALUE;
public static double maxLatitude=0;
public static double minLongitude=Double.MAX_VALUE;
public static double maxLongitude=0;
public String fileName ="population_distribution.csv";
public static int TaskNo = 1000; //00; // number of tasks
public static int TaskCount=0; //number of tasks generated so far
public static int WorkerNo = 100; //number of workers
public Cell[][] grid; 
public int factor = 200; //1000; //choosing this factor so that densities do not overlap and also densities dont get too far from each other

public static int rowCount=0;     //number of rows for the grid 
public static int colCount=0;    //number of cols for the grid 
public static int maxTasksPerWorker=10; // maximum # of tasks that a worker want to get
public ArrayList<EntropyRecord> densityList = new ArrayList();
public ArrayList<Worker> workerList = new ArrayList();
public ArrayList<Task> taskList = new ArrayList();
//public ArrayList<ArrayList<Task>> assignedTasks = new ArrayList<ArrayList<Task>>();
public static double maxRangePerc=0.05; //maximum range of an mbr is 5% of the entire x or y dimension
public static int TaskAssignedTotal=0;
//public static int costTotal=0;
public static int densityRecFullNo=0;// number of records which are already populated
public static int TaskDuration=1000; //duration of all tasks before they expire are fixed to 1000ms
//public static int TaskDuration=1000; //duration of all tasks before they expire are fixed to 1000ms
//public enum type{RANDOM,TIME,DENSITY};
public type assign_type = type.DENSITY;//DENSITY;
public static int sum_wait_time=0;
public int densitySum = 0;
public static int timeCounter =0; //works as the clock for task generation
public static int taskExpiredNo =0;
ArrayList[] container;  //for the mbr of every user, tells which tasks lay inside
//ArrayList inverted; //for every task says which mbrs it lays in
Hashtable<Integer, ArrayList> invertedTable;
public static String taskFileName = "tasks.txt";
public static String taskFileName2 = "tasks2.txt";

public static String workerFileName = "workers.txt";
public static String workerFileName2 = "workers2.txt";
public static String workerFileName3 = "workers3.txt";
public static String workerFileName4 = "workers4.txt";
public static String workerFileName5 = "workers5.txt";
//public static double maxRangeYPerc=;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
       
        GeoCrowd geoCrowd = new GeoCrowd();
        geoCrowd.findBoundaries();
        geoCrowd.createGrid();
        geoCrowd.populateGridWDensity();
        geoCrowd.printGrid();
       // geoCrowd.generateTasks();
        geoCrowd.readTasks(taskFileName);
       // for (int i=0; i<100; i++){
         // System.out.println("**************************round "+i+"******************");
         // geoCrowd.generateWorkers(workerFileName);
          geoCrowd.readWorkers(workerFileName);
          geoCrowd.assignAllWorkers();
          geoCrowd.calculateFlow();
          
          geoCrowd.readWorkers(workerFileName2);
          timeCounter +=500;
          geoCrowd.assignAllWorkers();
          geoCrowd.calculateFlow();
          
          geoCrowd.readTasks(taskFileName2);
          
          geoCrowd.readWorkers(workerFileName3);
          timeCounter +=500;
          geoCrowd.assignAllWorkers();
          geoCrowd.calculateFlow();
          
          geoCrowd.readWorkers(workerFileName4);
          timeCounter +=500;
          geoCrowd.assignAllWorkers();
          geoCrowd.calculateFlow();
          
           geoCrowd.readWorkers(workerFileName5);
          timeCounter +=200;
          geoCrowd.assignAllWorkers();
          geoCrowd.calculateFlow();
          //geoCrowd.calculateFlow(false,true);
          //geoCrowd.calculateFlow(true);
         // geoCrowd.test();
       //   if((i==10)||(i==20)||(i==30)||(i==40)||(i==50)||(i==60)||(i==70)||(i==80)||(i==90)){
         //   geoCrowd.generateTasks();
         // Thread.sleep(500);
         // }
        //  GeoCrowd.timeCounter +=100; 
       // }
      
        }catch(Exception e){e.printStackTrace();}
        
    }
    
    //this method finds the min max of lats and longs of the population distribution
    public void findBoundaries(){
          try{
             FileReader file = new FileReader(fileName);
             BufferedReader in = new BufferedReader(file);
             in.readLine();
             while (in.ready()){
                 String line = in.readLine();
                 String[] parts = line.split(",");
                 Double lat = Double.parseDouble(parts[2]);
                 Double lng = Double.parseDouble(parts[3]);
                 if( lat< minLatitude)
                     minLatitude = lat;
                 if( lat> maxLatitude)
                     maxLatitude = lat;
                 if( lng< minLongitude)
                     minLongitude = lng;
                 if( lng> maxLongitude)
                     maxLongitude = lng;
             }
             System.out.println("minLat:"+minLatitude+"   maxLat:"+maxLatitude+"   minLng:"+minLongitude+"   maxLng:"+maxLongitude);
         }catch(Exception e){
          e.printStackTrace();
         }
      }
   public void createGrid(){
       rowCount = (int)((maxLatitude-minLatitude)* factor)+1;
       colCount = (int)((maxLongitude-minLongitude)* factor)+1;
       grid = new Cell[rowCount][colCount];
   } 
   public void populateGridWDensity(){
       try{
             FileReader file = new FileReader(fileName);
             BufferedReader in = new BufferedReader(file);
             in.readLine();
             while (in.ready()){
                 String line = in.readLine();
                 String[] parts = line.split(",");
                 int d = Integer.parseInt(parts[1]);
                 Double lat = Double.parseDouble(parts[2]);
                 Double lng = Double.parseDouble(parts[3]);
                 int row= getRowIdx(lat);
                 int col = getColIdx(lng);
                 EntropyRecord dR = new EntropyRecord(d,row,col);
                 densityList.add(dR);
                 densitySum += d;
                 if (grid[row][col] != null){
                    grid[row][col].setDensity(d);
                   // System.out.println("not Null!!!!");
                 }
                 else{
                     grid[row][col] = new Cell(d);
                 }
             }
            System.out.println("sum of density: "+densitySum);
         }catch(Exception e){
          e.printStackTrace();
         }
   }
   
   public int getRowIdx(double lat){
       int row = (int)((lat - minLatitude)* factor);
       return row;
   }
   public int getColIdx(double lng){
       int col = (int)((lng - minLongitude)* factor);
       return col;
   }
   
   public double convertToLat(int row){  //for a given row , converts it back to latitude
       double lat = (((double)row)/factor) +minLatitude;
       return lat;
   }
   
   public double convertToLng(int col){  //for a given col , converts it back to longitude
       double lng = (((double)col)/factor) +minLongitude;
       return lng;
   }
   public void printGrid(){
       int existCnt=0;
       int nonExistCnt=0;
       for(int i=0; i<rowCount; i++){
           for(int j=0; j<colCount; j++){
               if (grid[i][j] != null){
                   System.out.print(grid[i][j].getDensity()+" ");
                   //System.out.print("+ ");
                   existCnt++;
               }
               else{
                   //grid[i][j] = new Cell(-1);
                   //System.out.print(grid[i][j].getDensity()+"  ");
                   System.out.print("  ");
                   nonExistCnt++;
               }
           }
           System.out.println();
       }
       System.out.println("rowCount: "+rowCount +"       colcount:"+ colCount);
       System.out.println("existing cells count: "+existCnt +"       non-existing cells:"+ nonExistCnt);
   }
   
  /* public void generateTasks(){
       int cnt=0;
       for (int i=0; i<TaskNo; i++){
           double lat = Math.random()* (maxLatitude-minLatitude) + minLatitude;
           double lng = Math.random()* (maxLongitude-minLongitude) + minLongitude;
           long time = System.currentTimeMillis();
           int k = 1;
           Task t = new Task(lat,lng,k, time);
           int rowIdx =  getRowIdx(lat);
           int colIdx =  getColIdx(lng);
           if (grid[rowIdx][colIdx] != null)
               grid[rowIdx][colIdx].addTask(t);
           else{
               grid[rowIdx][colIdx] = new Cell(-1);
               grid[rowIdx][colIdx].addTask(t);
               cnt++;
           }
               
           
       }
       System.out.println("number of tasks outside :"+cnt);
   }
    */
    public void generateTasks(String fileName){
        System.out.println("Tasks:");
        int listCount = taskList.size();
        //TaskCount =0;
        try{
        FileWriter writer = new FileWriter(fileName);
        BufferedWriter out = new BufferedWriter(writer);
        for(int i=0; i<TaskNo ; i++){
           //*******arbitrary task******
        /*    double lat = Math.random()* (maxLatitude-minLatitude) + minLatitude;
           double lng = Math.random()* (maxLongitude-minLongitude) + minLongitude;
           int row =  getRowIdx(lat);
           int col =  getColIdx(lng);*/
           //***************************
           
        //**********Task selection **********************
           int randomIdx = (int)(Math.random()*densityList.size());
           EntropyRecord dR = densityList.get(randomIdx);
           //generate a task inside this cell
           int row = dR.getRowIdx();
           double startLat = convertToLat(row);
           double endLat = convertToLat(row+1);
           double lat = Math.random()* (endLat-startLat) + startLat;
           int col = dR.getColIdx();
           double startLng = convertToLng(col);
           double endLng = convertToLng(col+1);
           double lng = Math.random()* (endLng-startLng) + startLng;
           int density = dR.getDensity();
           //*******************************
           int time = timeCounter++; 
           //long time = System.currentTimeMillis();
           int k = 1;
           Task t = new Task(lat,lng,k, time,density);
           out.write(lat+","+lng+","+k+","+time+","+density+"\n");
          // t.print();
           taskList.add(listCount, t);
           if (grid[row][col] != null)
               grid[row][col].addTask(listCount);
           else{
               grid[row][col] = new Cell(-1);
               grid[row][col].addTask(listCount);
           }
           listCount++;
           //Thread.sleep(1);
        
       }
        TaskCount += TaskNo;
        System.out.println("number of tasks generated so far:"+TaskCount);
        out.close();
       }catch(Exception e){}
   }
    
    public void readTasks(String fileName){
        System.out.println("Tasks:");
        int listCount = taskList.size();
        //TaskCount =0;
        try{
        FileReader reader = new FileReader(fileName);
        BufferedReader in = new BufferedReader(reader);
        while (in.ready()){
            String line = in.readLine();
            String[] parts = line.split(",");
            double lat = Double.parseDouble(parts[0]);
            double lng = Double.parseDouble(parts[1]);
            int k = Integer.parseInt(parts[2]);
            int time = Integer.parseInt(parts[3]);
            int density = Integer.parseInt(parts[4]);
            Task t = new Task(lat,lng,k, time,density);
            taskList.add(listCount, t);
            int row = getRowIdx(lat);
            int col = getColIdx(lng);
           if (grid[row][col] != null)
               grid[row][col].addTask(listCount);
           else{
               grid[row][col] = new Cell(-1);
               grid[row][col].addTask(listCount);
           }
           listCount++;
           
        }
        TaskCount += TaskNo;
        System.out.println("number of tasks generated so far:"+TaskCount);
        in.close();
       }catch(Exception e){}
   }
    
   public void generateWorkers(String fileName){
       workerList = new ArrayList();
       int maxSumTaskWorkers=0;
       System.out.println("Workers:");
       double maxRangeX = (maxLatitude-minLatitude)*maxRangePerc;
       double maxRangeY = (maxLongitude-minLongitude)*maxRangePerc;
        try{
        FileWriter writer = new FileWriter(fileName);
        BufferedWriter out = new BufferedWriter(writer);
        
       for(int i=0; (i<WorkerNo) && (densityRecFullNo<densityList.size()); i++){
           int randomIdx = (int)(Math.random()*densityList.size());
           EntropyRecord dR = densityList.get(randomIdx);
           if (dR.getWorkerNo()<dR.getDensity()){
               //generate a worker inside this cell
               int row = dR.getRowIdx();
               double startLat = convertToLat(row);
               double endLat = convertToLat(row+1);
               double lat = Math.random()* (endLat-startLat) + startLat;
               int col = dR.getColIdx();
               double startLng = convertToLng(col);
               double endLng = convertToLng(col+1);
               double lng = Math.random()* (endLng-startLng) + startLng;
               int maxT = (int) (Math.random()* maxTasksPerWorker)+1; 
               maxSumTaskWorkers += maxT;
               double rangeX = Math.random()* maxRangeX;
               double rangeY = Math.random()* maxRangeY;
               MBR mbr = MBR.createMBR(lat, lng, rangeX, rangeY);
               checkBoundaryMBR(mbr);
               Worker w = new Worker(lat,lng,maxT,mbr);
              // w.print();
               out.write(randomIdx+","+lat+","+lng+","+maxT+","+"["+mbr.getMinLat()+","+mbr.getMaxLat()+","+mbr.getMinLng()+","+mbr.getMaxLng()+"]\n");
               workerList.add(w);
               dR.incWorkerNo();
               if (dR.getWorkerNo()==dR.getDensity())
                   densityRecFullNo++;
           }
           else{
               i--;
              // System.out.println("one decremented!");
           }
           //  while(densityList.get(randomIdx).getActiveDensityNo())
         //  while(densityList.get(randomIdx).getActiveDensityNo())
           
       }
          out.close();
       }catch(Exception e){}
       System.out.println("Workers generated!");
       System.out.println("sum of maxTask of all workers:"+maxSumTaskWorkers);
   }
   
   public void readWorkers(String fileName){
       workerList = new ArrayList();
       int maxSumTaskWorkers=0;
       System.out.println("Workers:");
       double maxRangeX = (maxLatitude-minLatitude)*maxRangePerc;
       double maxRangeY = (maxLongitude-minLongitude)*maxRangePerc;
        try{
        FileReader reader = new FileReader(fileName);
        BufferedReader in = new BufferedReader(reader);
        while(in.ready()){
            String line = in.readLine();
            line = line.replace("[", "");
            line = line.replace("]", "");
            String[] parts = line.split(",");
            int randomIdx = Integer.parseInt(parts[0]);
            EntropyRecord dR = densityList.get(randomIdx);
             //if (dR.getWorkerNo()<dR.getDensity()){
                double lat = Double.parseDouble(parts[1]);
                double lng = Double.parseDouble(parts[2]);
                int maxT = Integer.parseInt(parts[3]);
                maxSumTaskWorkers += maxT;
                double mbr_minLat = Double.parseDouble(parts[4]);
                double mbr_maxLat = Double.parseDouble(parts[5]);
                double mbr_minLng = Double.parseDouble(parts[6]);
                double mbr_maxLng = Double.parseDouble(parts[7]);
                MBR mbr = new MBR(mbr_minLat, mbr_maxLat, mbr_minLng, mbr_maxLng);
                Worker w = new Worker(lat,lng,maxT,mbr);
                workerList.add(w);
                dR.incWorkerNo();
                if (dR.getWorkerNo()==dR.getDensity())
                   densityRecFullNo++;
             //}
             //else System.out.println("")
        }
      
          in.close();
       }catch(Exception e){}
       System.out.println("Workers generated!");
       System.out.println("sum of maxTask of all workers:"+maxSumTaskWorkers);
   }
   
   public void checkBoundaryMBR(MBR mbr){
       if(mbr.getMinLat()<minLatitude)
           mbr.setMinLat(minLatitude);
       if(mbr.getMaxLat() > maxLatitude)
           mbr.setMaxLat(maxLatitude);
       if(mbr.getMinLng()<minLongitude)
           mbr.setMinLng(minLongitude);
       if(mbr.getMaxLng() > maxLongitude)
           mbr.setMaxLng(maxLongitude);
   }
   public void assignAllWorkers(){
       invertedTable = new Hashtable<Integer, ArrayList>(); 
       container = new ArrayList[workerList.size()];
       //inverted = new ArrayList();
       for(int i=0; i<workerList.size();i++){
           timeCounter++;
           Worker w = workerList.get(i);
           ArrayList<TaskDetail> retrievedTasks = rangeQuery(i,w.getMBR());
           //container[i]  = rangeQuery(i,w.getMBR());

          //assignWorker(i,w);
       } 
        
   }
   
 /*  public void test(){
       for(int i=0; i<workerList.size();i++){
           timeCounter++;
           Worker w = workerList.get(i);
           assignWorker(i,w);
       } 
       System.out.println("total number of tasks assigned: "+TaskAssignedTotal+"    out of total tasks: "+TaskCount);
       System.out.println("total wait time: "+sum_wait_time);
       System.out.println("number of expired tasks : "+taskExpiredNo);
   }*/
   /*
     public void assignAllWorkers(){
       for(int i=0; i<workerList.size();i++){
           timeCounter++;
           Worker w = workerList.get(i);
           assignWorker(w);
       } 
       System.out.println("total number of tasks assigned: "+TaskAssignedTotal+"    out of total tasks: "+TaskCount);
       System.out.println("total wait time: "+sum_wait_time);
       System.out.println("number of expired tasks : "+taskExpiredNo);
   }*/
/*    public void assignWorker(int workerIdx, Worker w){
       ArrayList<TaskDetail> retrievedTasks = rangeQuery(workerIdx,w.getMBR());
       int retrievedSize = retrievedTasks.size();
       if (retrievedSize ==0)
           System.out.println("no task for this worker to do!!");
       else if (retrievedSize < w.getMaxTaskNo()) { ///assign all tasks to the worker
           System.out.println("Available tasks less than the worker capacity --> Assigning "+retrievedSize);
           for(TaskDetail tD: retrievedTasks){
               Integer t = (Integer)grid[tD.getRowIdx()][tD.getColIdx()].getTaskList().get(tD.getListIdx());
               Task task = taskList.get(t);
               if(!task.isAssigned()){
                   task.setAssigned();
                   TaskAssignedTotal++;
               }
               else{
              System.out.println("task is already assigned!");
                }
           }
       }
       else{
           if (assign_type == type.RANDOM)
              RandomAssign(w,retrievedTasks);
           else if (assign_type == type.FIFO)
              FifoAssign(w, retrievedTasks);
           else if (assign_type == type.DENSITY)
              DensityAssign(w, retrievedTasks);
           else if (assign_type == type.DENSITYFIFO)
               DensityFIFOAssign(w, retrievedTasks);
           else
               FIFODensityAssign(w, retrievedTasks);
       }
   }
    
    */
   public ArrayList rangeQuery(int workerIdx,MBR mbr){
       //ArrayList<Task> retrievedTasks = new ArrayList();
       ArrayList<TaskDetail> retrievedTasks = new ArrayList<TaskDetail>();
       int minRow = getRowIdx(mbr.getMinLat());
       int maxRow = getRowIdx(mbr.getMaxLat());
       int minCol = getColIdx(mbr.getMinLng());
       int maxCol = getColIdx(mbr.getMaxLng());
    //  long curTime = System.currentTimeMillis();
       for(int i= minRow; i<=maxRow; i++){
           for(int j= minCol; j<=maxCol; j++){
               if (grid[i][j] != null){
                  ArrayList<Integer> tasks= grid[i][j].getTaskList();
                  if (tasks != null){
                    int k=0;
                    for(Integer t:tasks){
                        Task task = taskList.get(t);
                        if (!task.isAssigned()){
                            if (!task.isExpired()){
                             if ((timeCounter - task.getEntryTime()) < TaskDuration){
                            TaskDetail taskDet = new TaskDetail(task.getEntryTime(), i, j, k, grid[i][j].getDensity());
                            retrievedTasks.add(taskDet);
                            if(container[workerIdx] == null){
                                container[workerIdx] = new ArrayList();
                            }
                            container[workerIdx].add(t);
                            if (!invertedTable.containsKey(t)){
                               ArrayList arr = new ArrayList();
                               arr.add(workerIdx);
                               invertedTable.put(t, arr);
                            }
                            else{
                                ArrayList arr = invertedTable.get(t);
                                arr.add(workerIdx);
                                invertedTable.put(t, arr);
                            }
                            }
                             else{
                                 task.setExpired();
                                 System.out.println("task expired");
                             }
                           }
                        }
                        else {
                            System.out.println("task is already assigned!");
                        }
                        k++;
                    }
                  }
               }
           }
       }
       
       
       return retrievedTasks;
 }
  /* 
 public void RandomAssign(Worker w,ArrayList<TaskDetail> tasksIdx){
     System.out.println("random assignment");
     int cnt=0;
     long curTime = System.currentTimeMillis();
     
     for(int i=0 ; i<tasksIdx.size() && cnt<w.getMaxTaskNo(); i++){
         TaskDetail tD = tasksIdx.get(i);
          Integer t = (Integer)grid[tD.getRowIdx()][tD.getColIdx()].getTaskList().get(tD.getListIdx());
          Task task = taskList.get(t);
          if (!task.isAssigned()){
          //if (!t.isAssigned()&&((timeCounter- t.getEntryTime()) < TaskDuration)){
             if((timeCounter- task.getEntryTime()) < TaskDuration){
            //if((curTime- t.getEntryTime()) < TaskDuration){
             task.setAssigned();
             TaskAssignedTotal++;
             cnt++;
             //sum_wait_time += curTime - t.getEntryTime();
             sum_wait_time += timeCounter - task.getEntryTime();
             } 
             else {
                taskExpiredNo++;
                task.setExpired();
            }
          }
          else{
              System.out.println("task is already assigned!");
          }
          
     }
    //while(cnt<w.getMaxTaskNo()){
         //int randomIdx = (int)(Math.random()*tasksIdx.size());
         //TaskDetail tD = tasksIdx.get(randomIdx);
         //Task t = (Task)grid[tD.getRowIdx()][tD.getColIdx()].getTaskList().get(tD.getListIdx());
         //if(!t.isAssigned()&&((curTime - t.getEntryTime()) < TaskDuration)){
         //   t.setAssigned();
          //  TaskAssignedTotal++;
        //    cnt++;
      //         }
        
    // }
     System.out.println("random assignment --> assigned:"+cnt+"   tasks");
 }
 */
 /*public void FifoAssign(Worker w,ArrayList<TaskDetail> tasksIdx){
     System.out.println("FIFO assignment");
     //long[] timeList = new long[tasks.size()];
   //  ArrayList<TaskDetail> tasks = new ArrayList();
    // long curTime = System.currentTimeMillis();
  //   for(int i = 0 ; i< tasksIdx.size(); i++){
    //    int[] rec = tasksIdx.get(i);
    //    Task t = (Task)grid[rec[0]][rec[1]].getTaskList().get(rec[2]);
     //   if(!t.isAssigned()){
      //      if ((curTime - t.getEntryTime()) < TaskDuration){
       //         TaskDetail taskDet = new TaskDetail(t.getEntryTime(), rec[0], rec[1], rec[2]);
        //        tasks.add(taskDet);
         //   }
       // }
    // }
     long curTime = System.currentTimeMillis();
     Collections.sort(tasksIdx,new TaskDetailTimeComparator());
     int cnt=0;
     for(int i=0 ; i<tasksIdx.size() && cnt<w.getMaxTaskNo(); i++){
         TaskDetail tD = tasksIdx.get(i);
          Integer t = (Integer)grid[tD.getRowIdx()][tD.getColIdx()].getTaskList().get(tD.getListIdx());
          Task task = taskList.get(t);
          if (!task.isAssigned()){
           //if((curTime- t.getEntryTime()) < TaskDuration){
           if ((timeCounter- task.getEntryTime()) < TaskDuration){
             task.setAssigned();
             TaskAssignedTotal++;
             cnt++;
             //sum_wait_time += curTime - t.getEntryTime();
             sum_wait_time += timeCounter - task.getEntryTime();
           }
             else {
               taskExpiredNo++;
               task.setExpired();
           }
          }
     }
    
     System.out.println("Fifo assignment --> assigned:"+cnt+"   tasks");
 }
 */
/* public void DensityAssign(Worker w,ArrayList<TaskDetail> tasksIdx){
     System.out.println("Density assignment");
  
     Collections.sort(tasksIdx,new TaskDensityComparator());
     
     int cnt=0;
     for(int i=0 ; i<tasksIdx.size() && cnt<w.getMaxTaskNo(); i++){
         TaskDetail tD = tasksIdx.get(i);
          Integer t = (Integer)grid[tD.getRowIdx()][tD.getColIdx()].getTaskList().get(tD.getListIdx());
          Task task = taskList.get(t);
          if (!task.isAssigned()){
             task.setAssigned();
             TaskAssignedTotal++;
             cnt++;
          }
     }
    
     System.out.println("Density assignment --> assigned:"+cnt+"   tasks");
 }
 */
 /* public void DensityFIFOAssign(Worker w,ArrayList<TaskDetail> tasksIdx){
     System.out.println("Density FIFO assignment");
  
     Collections.sort(tasksIdx,new TaskDensityComparator());
     
     int cnt=0;
     ArrayList<TaskDetail> sameDensityList = new ArrayList();
     int lastDensity=-1;
     for(int i=0 ; i<tasksIdx.size() && cnt<w.getMaxTaskNo(); i++){
         TaskDetail tD = tasksIdx.get(i);
         if(lastDensity!=tD.getDensity()){
             if (sameDensityList.size()>0){
                 Collections.sort(sameDensityList, new TaskDetailTimeComparator());
                 for(int j=0; j<sameDensityList.size() &&  cnt<w.getMaxTaskNo(); j++){
                     TaskDetail tD2 = sameDensityList.get(j);
                     Integer t = (Integer)grid[tD2.getRowIdx()][tD2.getColIdx()].getTaskList().get(tD2.getListIdx());
                     Task task = taskList.get(t);
                     if (!task.isAssigned()){
                        task.setAssigned();
                        TaskAssignedTotal++;
                        cnt++;
                     }
                 }
                 
             }
             
             sameDensityList = new ArrayList();
         }
         //if((sameDensityList.size()<=0)||(lastDensity==tD.getDensity())){
             sameDensityList.add(tD);
             lastDensity = tD.getDensity();
         //}
        
     }
    
     System.out.println("Density then FIFO assignment --> assigned:"+cnt+"   tasks");
 }
 */
 /* public void FIFODensityAssign(Worker w,ArrayList<TaskDetail> tasksIdx){
     System.out.println("FIFO Density assignment");
  
     Collections.sort(tasksIdx,new TaskDetailTimeComparator());
     
     int cnt=0;
     ArrayList<TaskDetail> sameDensityList = new ArrayList();
     int lastDensity=-1;
     for(int i=0 ; i<tasksIdx.size() &&  cnt<w.getMaxTaskNo(); i++){
         TaskDetail tD = tasksIdx.get(i);
         if(lastDensity!=tD.getDensity()){
             if (sameDensityList.size()>0){
                 Collections.sort(sameDensityList, new TaskDensityComparator());
                 for(int j=0; j<sameDensityList.size() &&  cnt<w.getMaxTaskNo(); j++){
                     TaskDetail tD2 = sameDensityList.get(j);
                     Integer t = (Integer)grid[tD2.getRowIdx()][tD2.getColIdx()].getTaskList().get(tD2.getListIdx());
                     Task task = taskList.get(t);
                     if (!task.isAssigned()){
                        task.setAssigned();
                        TaskAssignedTotal++;
                        cnt++;
                     }
                 }
                 
             }
             
             sameDensityList = new ArrayList();
         }
         //if((sameDensityList.size()<=0)||(lastDensity==tD.getDensity())){
             sameDensityList.add(tD);
             lastDensity = tD.getDensity();
         //}
        
     }
    
     System.out.println("FIFO then Density  assignment --> assigned:"+cnt+"   tasks");
 }
 */
 public double calculateFlow(){//ArrayList[] contain, ArrayList invert,boolean multQuery){
       if(container.length != invertedTable.size())
            System.out.println("the two sets are not of equal size!!!!");
        int V = container.length + taskList.size();
       // int E=0;
        // int E = Integer.parseInt(args[1]);
        int s = V, t = V+1;//int s = 0, t = V-1;
        
        FlowNetwork G = new FlowNetwork(V,container, workerList,taskList,assign_type);
        //System.out.println(G);
//************************************************8
        
        //***********************************************
         // compute maximum flow and minimum cut
        FordFulkerson maxflow = new FordFulkerson(G, s, t,assign_type,workerList.size(),taskList);
        System.out.println("Max flow from " + s + " to " + t);
        int cnt=0;
      
        // print min-cut
        System.out.print("Min cut: ");
        for (int v = 0; v < G.V(); v++) {
            if (maxflow.inCut(v)) System.out.print(v + " ");
        }
        System.out.println();
        TaskAssignedTotal += maxflow.value();
        System.out.println("Max flow value = " +  maxflow.value()+ "    with min cost: "+maxflow.minCost()+"     with mincost2: "+maxflow.minCost2);
        System.out.println("total number of assigned tasks:"+TaskAssignedTotal);
 //********************************************8888
         // compute maximum flow and minimum cut
    /*     G = new FlowNetwork(V,container, workerList,taskList);
         maxflow = new FordFulkerson(G, s, t,fifo,true);
        System.out.println("Max flow-min cost from " + s + " to " + t);
         cnt=0;
        for (int v = 0; v < G.V(); v++) {
            for (FlowEdge e : G.adj(v)) {
                if ((v == e.from()) && e.flow() > 0){
                  //  System.out.print("   " + e);
                    if(e.from()==(e.to()-container.length)){
                        cnt++;
                     }

                }

            }
           // System.out.println();
        }
        System.out.println("  number of correct matches " + cnt);
        // print min-cut
        System.out.print("Min cut: ");
        for (int v = 0; v < G.V(); v++) {
            if (maxflow.inCut(v)) System.out.print(v + " ");
        }
        System.out.println();
        System.out.println("Max flow value = " +  maxflow.value()+ "    with min cost: "+maxflow.minCost()+"     with mincost2: "+maxflow.minCost2);
  */
        //***************************************************************
        return (100*cnt/(invertedTable.size()+1));
   }

}
