/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

import java.util.Comparator;

/**
 *
 * @author Leyla
 */
public class TaskDensityComparator implements Comparator{
    
    public int compare(Object O1, Object O2){
        int t1 = ((TaskDetail) O1).getDensity();
        int t2 = ((TaskDetail) O2).getDensity();
        if (t1>t2)
            return 1;
        else if (t1<t2)
            return -1;
        else 
            return 0;
        
    }
    
}
