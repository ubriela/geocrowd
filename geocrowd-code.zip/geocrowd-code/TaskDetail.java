/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

/**
 *
 * @author Leyla
 */
public class TaskDetail {
    private int entryTime;
    private int rowIdx;
    private int colIdx;
    private int listIdx;
    private int density;
    public TaskDetail(int t , int i, int j, int k,int dens){
        entryTime = t;
        rowIdx = i;
        colIdx = j;
        listIdx = k;
        density = dens;
    }
    public int getEntryTime(){
        return entryTime;
    }
    public int getRowIdx(){
        return rowIdx;
    }
    public int getColIdx(){
        return colIdx;
    }
    public int getListIdx(){
        return listIdx;
    }
    public int getDensity(){
        return density;
    }
    
}
