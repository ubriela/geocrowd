/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

/**
 *
 * @author Leyla
 */
public class Task {
    private double lat;
    private double lng;
    private int k;
    private int entryTime;
    private int assigned=0;
    private boolean expired=false;
    private double entropy;
    private int entropyRowId;
    public Task(double lt, double ln, int K, int entry,double dens,int row){
        lat = lt;
        lng = ln;
        k = K;
        entryTime = entry;
        entropy = dens;
        entropyRowId = row;
    }
    
    /*public double[] getPoint(){
        return point;
    }
    */
    public int getEntryTime(){
        return entryTime;
    }
    public double getLat(){
        return lat;
    }
    public double getLng(){
        return lng;
    }
     public int getEntropyRowId(){
        return entropyRowId;
    }
    public void print(){
        System.out.println("lat:"+lat+"   lng:"+lng+"   k:"+k+"   time:"+entryTime);
    }
    public boolean isAssigned(){
        return (assigned>=k);
    }
    public void incAssigned(){
        assigned++;
    }
    
    public boolean isExpired(){
        return expired;
    }
    public void setExpired(){
        expired =true;
    }
    public double getEntropy(){
        return entropy;
    }
    public boolean isOverlapped(double minLat_mbr,double minLng_mbr,double maxLat_mbr, double maxLng_mbr){
        boolean overlapped = false;
        if((lat>=minLat_mbr)&&(lat<=maxLat_mbr)&&(lng>=minLng_mbr)&&(lng<=maxLng_mbr))
            overlapped =true;
        return overlapped;
    }
}
