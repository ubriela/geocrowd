/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

public enum type{RANDOM,TIME,ENTROPY,KNN};