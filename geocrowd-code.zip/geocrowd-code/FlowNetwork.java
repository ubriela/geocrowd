/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package geocrowd;

import java.io.*;
import java.util.*;
/*************************************************************************
 *  Compilation:  javac FlowNetwork.java
 *  Execution:    java FlowNetwork V E
 *  Dependencies: Bag.java FlowEdge.java
 *
 *  A capacitated flow network, implemented using adjacency lists.
 *
 *************************************************************************/

public class FlowNetwork {
    private final int V;
    private int E;
    private ArrayList<FlowEdge>[] adj;

    // empty graph with V vertices
    public FlowNetwork(int V) {
        this.V = V;
        this.E = 0;
        adj =  new ArrayList[V];
        for (int v = 0; v < V; v++)
            adj[v] = new ArrayList();
    }
  /* 
    // random graph with V vertices and E edges
    public FlowNetwork(int V, int E) {
        this(V);
        for (int i = 0; i < E; i++) {
            int v =(int) (Math.random()*V);// StdRandom.uniform(V);
            int w = (int)(Math.random()*V);//StdRandom.uniform(V);
            double capacity = 1;//Math.random()*100;//StdRandom.uniform(100);
            addEdge(new FlowEdge(v, w, capacity));
        }
    }*/
 // random graph with V vertices and E edges
    public FlowNetwork( int V, ArrayList[] List, ArrayList<Worker> workerList,ArrayList<Task> taskList, type assign_type) {
        this(V+2);
        double capacity = 1;
        for(int i = 0; i < List.length; i++) {
            int maxTask = workerList.get(i).getMaxTaskNo(); 
            double workerLat = workerList.get(i).getLatitude();
            double workerLng = workerList.get(i).getLongitude();
        //for(int i = List.size()-1; i>=0; i--) {
            ArrayList tasks  =(ArrayList) List[i];
            if(tasks != null){
            for(int j = 0; j < tasks.size(); j++) {
           // for(int j = regions.size()-1; j >=0; j--) {
                int t = (Integer) tasks.get(j);
                Task task = taskList.get(t); 
                double taskLat = task.getLat();
                double taskLng = task.getLng();
                double dist = Math.sqrt(((workerLat - taskLat)*(workerLat - taskLat))+((workerLng - taskLng)*(workerLng - taskLng))); 
              //  if (dist == Double.NaN)
                //    System.out.println("booooogh");
                //double capacity = 1;//Math.random()*100;//StdRandom.uniform(100);
                /*if((i==0) && (j==0))
                    System.out.println("i=0 j=0!!!");
                else if((i==41) && (j==0))
                    System.out.println("i=41 j=0!!!");
                else if((i==75) && (j==0))
                    System.out.println("i=75 j=0!!!");
                else*/
                   if(assign_type == type.ENTROPY)
                       addEdge(new FlowEdge(i, List.length+t, capacity,task.getEntropy(),dist));
                   else if(assign_type == type.KNN)
                        addEdge(new FlowEdge(i, List.length+t, capacity,dist,dist));
                   else
                        addEdge(new FlowEdge(i, List.length+t, capacity,task.getEntryTime(),dist));
            }
           /* for(int j = 1; j < regions.size(); j+=2) {
                   int region = (Integer) regions.get(j);
                   addEdge(new FlowEdge(i, (V/2)+region, capacity));
            }*/

            //for the case of a user asking more than one query
           // if(multQuery)
             //   addEdge(new FlowEdge(V, i, Integer.MAX_VALUE));  //this is for adding edges from source to all points
            //else
               
            //addEdge(new FlowEdge((List.length)+i, V+1, capacity)); //this is for adding edges from all regions to t
        }
             addEdge(new FlowEdge(V, i, maxTask,0,0));  //this is for adding edges from source to all points
        }
        for(int i =  0; i < taskList.size(); i++) {
              Task task = taskList.get(i); 
              addEdge(new FlowEdge(List.length+ i, V+1, capacity,0,0));
         }
        /* for(int i =  List.length; i < V; i++) {
              addEdge(new FlowEdge(i, V+1, capacity));
         }
       */
    }
    // graph, read from input stream
  /*  public FlowNetwork(In in) {
        this(in.readInt());
        int E = in.readInt();
        for (int i = 0; i < E; i++) {
            int v = in.readInt();
            int w = in.readInt();
            double capacity = in.readDouble();
            addEdge(new FlowEdge(v, w, capacity));
        }
    }
*/

    // number of vertices and edges
    public int V() { return V; }
    public int E() { return E; }

    // add edge e in both v's and w's adjacency lists
    public void addEdge(FlowEdge e) {
        E++;
        int v = e.from();
        int w = e.to();
        adj[v].add(e);
        adj[w].add(e);
    }

    // return list of edges incident to  v
    public ArrayList<FlowEdge> adj(int v) {
        return adj[v];
    }
   

    // return list of all edges
    public Iterable<FlowEdge> edges() {
        ArrayList<FlowEdge> list = new ArrayList<FlowEdge>();
        for (int v = 0; v < V; v++)
            for (FlowEdge e : adj(v))
                list.add(e);
        return list;
    }


    // string representation of Graph - takes quadratic time
    public String toString() {
        String NEWLINE = System.getProperty("line.separator");
        StringBuilder s = new StringBuilder();
        s.append(V + " " + E + NEWLINE);
        for (int v = 0; v < (V-2)/2; v++) {
            s.append(v + ":  ");
            for (FlowEdge e : adj[v]) {
                s.append(e + "  ");
            }
            s.append(NEWLINE);
        }
        return s.toString();
    }

    // test client
    /*public static void main(String[] args) {
        int V = Integer.parseInt(args[0]);
        int E = Integer.parseInt(args[1]);
        FlowNetwork G = new FlowNetwork(V, E);

        System.out.println(G);
    }
*/
}

