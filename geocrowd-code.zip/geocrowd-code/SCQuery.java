/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

import java.util.ArrayList;

/**
 *
 * @author Leyla
 */
public class SCQuery {
    private ArrayList<Task> TaskList;
    private long entryTime;
    public SCQuery(ArrayList list, long time){
        TaskList = new ArrayList(list);
        entryTime = time;
    }
    public SCQuery(){
        TaskList = new ArrayList();
    }
    public ArrayList getTasks(){
        return TaskList;
    }
    public long getEntryTime(){
        return entryTime;
    }
    
    
}
