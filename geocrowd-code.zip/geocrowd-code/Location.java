/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

/**
 *
 * @author Leyla
 */
public class Location {
    private double lat;
    private double lng;
    public Location(double lt , double ln){
        lat = lt;
        lng = ln;
    }
    public double getLat(){
        return lat;
    }
    public double getLng(){
        return lng;
    }
   
}
