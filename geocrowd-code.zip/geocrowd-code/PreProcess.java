/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

import java.io.*;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

/**
 *
 * @author Leyla
 */
public class PreProcess {
    public static double minLatitude=33.8   ;//Double.MAX_VALUE;
    public static double maxLatitude=34.3;//(-1)*Double.MAX_VALUE;
    public static double minLongitude=-118.64;//Double.MAX_VALUE;
    public static double maxLongitude=-118.14;//(-1)*Double.MAX_VALUE;
    public static String gowallaFileName = "Gowalla_totalCheckins.txt";
    public static String gowallaFileName2 = "Gowalla_totalCheckins_CA.txt";
    public static String TaskFileName = "tasks/Gowalla_tasks";
    public static String entropyFileName = "Gowalla_entropy_2.txt";
    public static String entropyLocationFileName = "Gowalla_loc_entropy_2.txt";
    public static String synEntropyLocationFileName = "Syn_loc_entropy_2.txt";
    public static String synEntropyLocationFileName2 = "Syn_loc_entropy_LA.txt";
    public static String workerFileName = "workers/Gowalla_workers";
    
    //public Cell[][] grid; 
    public static int rowCount=0;     //number of rows for the grid 
    public static int colCount=0;    //number of cols for the grid
    public static int maxEntropy=10;
    public double resolution = 0.002; //this means that every grid cell is 0.0002 by 0.0002 in lat and long formats
        public Hashtable hashTable = new Hashtable();  //used for different purposes
     //   public Hashtable hashTable2 = new Hashtable();
    public static void main(String[] args) {
         PreProcess prep = new PreProcess();
        // prep.computeBoundary();
            prep.createGrid();
         //generating workers from Gowalla
         /*prep.generateWorkers();
         prep.saveWorkers();*/
           //prep.filterInput();//
         
         //reading entropy from Gowalla
        /*   prep.readData();
           prep.computeEntropy();
           prep.readLocationData();
           prep.saveLocationEntropy();
         */
         
         //synthetic entropy
         prep.saveLocationEntropy_Syn2();
         //   prep.createGrid();
         
         //
         
     }
    public void computeBoundary(){
         try{
             FileReader reader = new FileReader(gowallaFileName2);
             BufferedReader in = new BufferedReader(reader);
             int cnt =0;
             while ( in.ready()){
                 String line = in.readLine();
                 //System.out.println(line);
                // line = line.replace("  ", " ");
                 //System.out.println(line);
                 String[] parts = line.split("\\s");
                 Integer userID = Integer.parseInt(parts[0]);
                 Double lat = Double.parseDouble(parts[2]);
                 Double lng = Double.parseDouble(parts[3]);
                 Integer pointID = Integer.parseInt(parts[4]);
                 //114° 8' W to 124° 24' W
                 //Latitude: 32° 30' N to 42° N
                // if ((lat<32) || (lat>42) || (lng>(-114)) || (lng<(-125)))
                  //   continue;
                 if( lat< minLatitude)
                     minLatitude = lat;
                 if( lat> maxLatitude)
                     maxLatitude = lat;
                 if( lng< minLongitude)
                     minLongitude = lng;
                 if( lng> maxLongitude)
                     maxLongitude = lng;
                 //int row = getRowIdx(lat);
                 //int col = getColIdx(lng);
                // Grid g = new Grid(lat,lng);
                 
                 cnt++;
             }
             System.out.println("number of checkins: "+ cnt);
             System.out.println("minLat:"+minLatitude+"   maxLat:"+maxLatitude+"   minLng:"+minLongitude+"   maxLng:"+maxLongitude);
         }
         catch(Exception e)
         {
             e.printStackTrace();
         }
     }
     
     public void filterInput(){
         try{
             FileReader reader = new FileReader(gowallaFileName);
             BufferedReader in = new BufferedReader(reader);
             FileWriter writer = new FileWriter(gowallaFileName2);
             BufferedWriter out = new BufferedWriter(writer);
                          
             int cnt =0;
             while ( in.ready()){
                 String line = in.readLine();
                 //System.out.println(line);
                // line = line.replace("  ", " ");
                 //System.out.println(line);
                 String[] parts = line.split("\\s");
                 Integer userID = Integer.parseInt(parts[0]);
                 Double lat = Double.parseDouble(parts[2]);
                 Double lng = Double.parseDouble(parts[3]);
                 Integer pointID = Integer.parseInt(parts[4]);
                 //114° 8' W to 124° 24' W
                 //Latitude: 32° 30' N to 42° N
                 if ((lat<32) || (lat>42) || (lng>(-114)) || (lng<(-125)))
                     continue;
                 out.write(line+"\n");
                 
                 cnt++;
             }
             out.close();
             System.out.println("number of checkins: "+ cnt);
             System.out.println("minLat:"+minLatitude+"   maxLat:"+maxLatitude+"   minLng:"+minLongitude+"   maxLng:"+maxLongitude);
         }
             
         catch(Exception e)
         {
             e.printStackTrace();
         }
     }
     
      public void createGrid(){
       rowCount = (int)((maxLatitude-minLatitude)/ resolution)+1;
       colCount = (int)((maxLongitude-minLongitude)/ resolution)+1;
       System.out.println("rowcount: "+rowCount+"    colCount:"+colCount);
       //grid = new Cell[rowCount][colCount];
   } 

    public void readData(){
       try{
             FileReader reader = new FileReader(gowallaFileName2);
             BufferedReader in = new BufferedReader(reader);
             int cnt =0;
             while ( in.ready()){
                 String line = in.readLine();
                 //System.out.println(line);
                // line = line.replace("  ", " ");
                 //System.out.println(line);
                 String[] parts = line.split("\\s");
                 Integer userID = Integer.parseInt(parts[0]);
                 Double lat = Double.parseDouble(parts[2]);
                 Double lng = Double.parseDouble(parts[3]);
               //  if ((lat<32) || (lat>42) || (lng>(-114)) || (lng<(-125)))
                 //    continue;
                 Integer pointID = Integer.parseInt(parts[4]);
                 int row = getRowIdx(lat);
                 int col = getColIdx(lng);
                // Grid g = new Grid(row,col);
                 if (!hashTable.containsKey(pointID)){
                     ArrayList<Observation> u = new ArrayList<Observation>();
                     Observation o = new Observation(userID);
                     u.add(o);
                     hashTable.put(pointID, u);
                   //  Location loc = new Location(lat,lng);
                    // hashTable2.put(pointID, g);
                 }
                 else{
                     ArrayList<Observation> u = (ArrayList<Observation>) hashTable.get(pointID);
                     boolean found = false;
                     for (Observation o: u){
                         if (o.getUserId()==userID){
                             o.incObserveCount();
                             found = true;
                             break;
                         }
                     }
                     if(!found){
                        Observation o = new Observation(userID);
                        u.add(o); 
                     }
                 }
                 cnt++;
             }
             System.out.println("number of keys inserted into hash table:"+ hashTable.size());
          }
         catch(Exception e)
         {
             e.printStackTrace();
         }
    }
    
    public void generateWorkers(){
       try{
             FileReader reader = new FileReader(gowallaFileName2);
             BufferedReader in = new BufferedReader(reader);
             hashTable = new Hashtable();
             int cnt =0;
             while ( in.ready()){
                 String line = in.readLine();
                 String[] parts = line.split("\\s");
                 Integer userID = Integer.parseInt(parts[0]);
                 String[] DateTimeStr = parts[1].split("T");
                 Date date = Date.valueOf(DateTimeStr[0]);
                 Double lat = Double.parseDouble(parts[2]);
                 Double lng = Double.parseDouble(parts[3]);
                 MBR mbr = new MBR(lat-2*resolution,lng-2*resolution,lat+2*resolution,lng+2*resolution);
                 if(mbr.minLat<minLatitude) mbr.minLat = minLatitude;
                 if(mbr.maxLat>maxLatitude) mbr.maxLat = maxLatitude;
                 if(mbr.minLng<minLongitude) mbr.minLng = minLongitude;
                 if(mbr.maxLng>maxLongitude) mbr.maxLng = maxLongitude;
                 Integer pointID = Integer.parseInt(parts[4]);
                 Worker w = new Worker(userID,lat,lng,parts[1],mbr);
                 if (!hashTable.containsKey(date)){
                     ArrayList<Worker> u = new ArrayList<Worker>();
                     u.add(w);
                     hashTable.put(date, u);
                   
                 }
                 else{
                     ArrayList<Worker> u = (ArrayList<Worker>) hashTable.get(date);
                     boolean found = false;
                     for (Worker o: u){
                         if (o.getUserID()==userID){
                             o.incMaxTaskNo();
                             if (lat< o.getMBR().minLat)
                                 o.setMinLat(lat);
                             if (lat> o.getMBR().maxLat)
                                 o.setMaxLat(lat);
                             if (lng< o.getMBR().minLng)
                                 o.setMinLng(lng);
                             if (lng> o.getMBR().maxLng)
                                 o.setMaxLng(lng);
                             
                             found = true;
                             break;
                         }
                     }
                     if(!found){
                        u.add(w); 
                     }
                     
                 }
                 
                }
          }
         catch(Exception e)
         {
             e.printStackTrace();
         }
    }
    
 public void readLocationData(){
       try{
             hashTable = new Hashtable();
             FileReader reader = new FileReader(gowallaFileName2);
             BufferedReader in = new BufferedReader(reader);
             int cnt =0;
             while ( in.ready()){
                 String line = in.readLine();
                 //System.out.println(line);
                // line = line.replace("  ", " ");
                 //System.out.println(line);
                 String[] parts = line.split("\\s");
                 Integer userID = Integer.parseInt(parts[0]);
                 Double lat = Double.parseDouble(parts[2]);
                 Double lng = Double.parseDouble(parts[3]);
                 Integer pointID = Integer.parseInt(parts[4]);
              //   if ((lat<32) || (lat>42) || (lng>(-114)) || (lng<(-125)))
                //     continue;
                 int row = getRowIdx(lat);
                 int col = getColIdx(lng);
                 Grid g = new Grid(row,col);
                 if (!hashTable.containsKey(pointID)){
                     hashTable.put(pointID, g);
                   //  Location loc = new Location(lat,lng);
                    // hashTable2.put(pointID, g);
                 }
                 
                 cnt++;
             }
             System.out.println("number of keys inserted into hash table:"+ hashTable.size());
          }
         catch(Exception e)
         {
             e.printStackTrace();
         }
    }
    
        public void computeEntropy(){
     try{
      FileWriter writer = new FileWriter(entropyFileName);
      BufferedWriter out = new BufferedWriter(writer);
      Set<Integer> set = hashTable.keySet();

    Iterator<Integer> itr = set.iterator();
    while (itr.hasNext()) {
      int pointId = itr.next();
      ArrayList<Observation> u = (ArrayList<Observation>) hashTable.get(pointId);
      //System.out.println(pointId + ": " + hashTable2.get(pointId));
      int totalObservation=0;
      double entropy =0;
      for(Observation o: u){
          totalObservation += o.getObservationCount();
      }
      for(Observation o: u){
          int observeCount = o.getObservationCount();
          entropy += (((double)observeCount)/totalObservation)* Math.log((((double)observeCount)/totalObservation));
      }
      if (entropy != 0)
          entropy *= -1;
      out.write(pointId+","+entropy+"\n");
    }
    out.close();
     }
     catch(Exception e){
         e.printStackTrace();
     }
    }
     public void saveLocationEntropy(){
     try{
      FileReader reader = new FileReader(entropyFileName);
      BufferedReader in = new BufferedReader(reader);
      
      FileWriter writer = new FileWriter(entropyLocationFileName);
      BufferedWriter out = new BufferedWriter(writer);
      
      while (in.ready()) {
        String line = in.readLine();
        String[] parts = line.split(",");
        int pointId = Integer.parseInt(parts[0]);
        double entropy = Double.parseDouble(parts[1]);
        Grid g = (Grid) hashTable.get(pointId);
        out.write(pointId+","+g.getRowId()+","+g.getColId()+","+entropy+"\n");
    }
       out.close();
     }
     catch(Exception e){
         e.printStackTrace();
     }
    }
     
     public void saveWorkers(){
     try{
      Set<Date> set = hashTable.keySet();

    Iterator<Date> itr = set.iterator();
    Integer cnt=0;
    while (itr.hasNext()) {
      FileWriter writer = new FileWriter(workerFileName+cnt.toString()+".txt");
      BufferedWriter out = new BufferedWriter(writer);
     
        Date date = itr.next();
      ArrayList<Worker> u = (ArrayList<Worker>) hashTable.get(date);
      //System.out.println(pointId + ": " + hashTable2.get(pointId));
      for(Worker o: u){
          out.write(o.toStr()+"\n");
      }
      
      cnt++;
      out.close();
    }
    
     }
     catch(Exception e){
         e.printStackTrace();
     }
    }
    public int getRowIdx(double lat){
       int row = (int)((lat - minLatitude)/ resolution );
       return row;
   }
   public int getColIdx(double lng){
       int col = (int)((lng - minLongitude)/ resolution);
       return col;
   }
   
   public void saveLocationEntropy_Syn(){
     try{
      FileReader reader = new FileReader(entropyFileName);
      BufferedReader in = new BufferedReader(reader);
      
      FileWriter writer = new FileWriter(synEntropyLocationFileName);
      BufferedWriter out = new BufferedWriter(writer);
      
      while (in.ready()) {
        String line = in.readLine();
        String[] parts = line.split(",");
        int pointId = Integer.parseInt(parts[0]);
        double lat = (Math.random()*(maxLatitude-minLatitude))+minLatitude;
        double lng = (Math.random()*(maxLongitude-minLongitude))+minLongitude;
        int rowId = getRowIdx(lat);
        int colId = getColIdx(lng);
        double entropy = Math.random()*maxEntropy;
        out.write(pointId+","+rowId+","+colId+","+entropy+"\n");
    }
       out.close();
     }
     catch(Exception e){
         e.printStackTrace();
     }
    }
   
    public void saveLocationEntropy_Syn2(){
     try{
      
      FileWriter writer = new FileWriter(synEntropyLocationFileName);
      BufferedWriter out = new BufferedWriter(writer);
      int cnt=0;
      for(int i =0 ; i<rowCount; i++){
          for (int j=0; j<colCount; j++){
             double entropy = Math.random()*maxEntropy;
            out.write(cnt+","+i+","+j+","+entropy+"\n");
            cnt++;
          }
      }
     
       out.close();
     }
     catch(Exception e){
         e.printStackTrace();
     }
    }
    
    
       
}
