/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

import java.util.ArrayList;

/**
 *
 * @author Leyla
 */
public class EntropyRecord {
 // private ArrayList<Task> taskList;
    private double entropy;
    private int rowIdx;
    private int colIdx;
    private int workerNo;  //number of people chosen as workers; starts with 0 and is density as max
    public EntropyRecord(){
       // taskList = new ArrayList<Task>();
    }
    public EntropyRecord(double d, int r, int c){
        //taskList = new ArrayList<Task>();
        entropy = d;
        rowIdx = r; 
        colIdx = c;
        workerNo = 0;
    }
   /* public ArrayList getTaskList(){
        return taskList;
    }
    public void addTask(Task t){
        taskList.add(t);
    }*/
    public void setEntropy(int d){
        entropy = d ;
    }
    public double getEntropy(){
        return entropy;
    }
    public void setRowIdx(int row, int col){
        rowIdx = row;
        colIdx = col;
    }
    public int getRowIdx(){
        return rowIdx;
    }
    public int getColIdx(){
        return colIdx;
    }  
    public int getWorkerNo(){
        return workerNo;
    }
    public void incWorkerNo(){
        workerNo++;
    }
}
