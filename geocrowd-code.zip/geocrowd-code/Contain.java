/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

import java.util.ArrayList;

/**
 *
 * @author Leyla
 */
//this class tells for every task all the mbrs that cover the task
public class Contain {
    private int taskIdx;
    private ArrayList mbrs;
    public Contain(int ID, ArrayList m){
        taskIdx = ID;
        mbrs = m;
    }
    
    public int getTaskIdx(){
        return taskIdx;
    }
   public ArrayList getMBRs(){
       return mbrs;
   }   
}
