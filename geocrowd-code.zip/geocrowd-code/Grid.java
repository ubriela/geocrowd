/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

/**
 *
 * @author Leyla
 */
public class Grid {

    private int rowId;
    private int colId;
    public Grid(int r , int c){
        rowId = r;
        colId = c;
    }
    public int getRowId(){
        return rowId;
    }
    public int getColId(){
        return colId;
    }
    
}
