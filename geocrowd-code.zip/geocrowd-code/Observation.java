/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geocrowd;

/**
 *
 * @author Leyla
 */
public class Observation {
    private int userId;
    private int observeCount;
    
    public Observation(int u){
        userId = u;
        observeCount =1;
    }
    public int getUserId(){
        return userId;
    }
    public int getObservationCount(){
        return observeCount;
    }
    public void incObserveCount(){
        observeCount++;
    }
}
